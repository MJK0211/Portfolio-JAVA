package com.pikka.domain;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Locker {
	
	private String lockerNo;
	private int lockerStatus;
	

}
