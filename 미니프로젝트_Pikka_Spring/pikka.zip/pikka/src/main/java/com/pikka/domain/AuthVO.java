package com.pikka.domain;

import java.util.List;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class AuthVO {

	private String userId;
	private String auth;
	
}
