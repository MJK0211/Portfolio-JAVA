package com.pikka.domain;

import lombok.Data;

@Data
public class Seat {
	
	private String seatNo;
	private int seatStatus;	


}
